This file contains instructions for how to simulate a real-scale, spiking neural network
model of hippocampal area CA2. Listed below are sections containing instructions on
simulating in an environment of the user's choice, or within CARLsim, the preferred
simulation environment for Hippocampome.org.


*SECTION FOR USER CHOICE ENVIRONMENT*
*Describe in a few sentences what the parameter XL is and what it contains, and then user
can use the parameter estimates in the XL to simulate in their environment choice.*



*SECTION FOR CARLSIM*
The CARLsim folder contains all that is necessary to simulate the CA2 real-scale network
in CARLsim. *A few sentences describing the CARLsim folder contents.*
Further detailed instructions can be found on (github link).