This file contains instructions for how to simulate a real-scale, spiking neural network
model of hippocampal area CA3. Listed below are sections containing instructions on
simulating in an environment of the user's choice, or within CARLsim, the preferred
simulation environment for Hippocampome.org.


*SIMULATING THE SNN IN ENVIRONMENT OF CHOICE*

We have provided an XL that contains  parameter values for both neuron and connection types to simulate a real-scale 
spiking neural network (SNN) model of CA3. Values color-coded in light blue have been estimated based on experimental evidence 
and exist on Hippocampome.org. Values color-coded in red are default parameter values from CARLsim. Parameter sets that define the 
neuron type's input-output relationship are for the 9-parameter Izhikevich model formalism, and those that define a connection type's 
short-term plasticity are for the Tsodyks-Pawelzik-Markram (TPM) formalism. Importantly, these parameter values are simulator agnostic,
so one can simulate the full scale CA3 SNN in an environment of their choice (e.g., NEURON, Brian 2, NEST, etc.). 


*SIMULATING THE SNN IN CARLSIM*
The CARLsim folder contains all code that is necessary to simulate the CA3 real-scale network
in CARLsim. Further detailed instructions can be found at https://github.com/jkopsick/CARLsim6/tree/feat/CS6_hc/projects.