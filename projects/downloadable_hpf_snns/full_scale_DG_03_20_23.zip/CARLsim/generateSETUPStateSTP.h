sim.setSpikeMonitor(DG_Granule, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Hilar_Ectopic_Granule, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Semilunar_Granule, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Mossy, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Mossy_MOLDEN, "DEFAULT");
                             
sim.setSpikeMonitor(DG_AIPRIM, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Basket_CCK, "DEFAULT");
                             
sim.setSpikeMonitor(DG_HICAP, "DEFAULT");
                             
sim.setSpikeMonitor(DG_HIPP, "DEFAULT");
                             
sim.setSpikeMonitor(DG_HIPROM, "DEFAULT");
                             
sim.setSpikeMonitor(DG_MOCAP, "DEFAULT");
                             
sim.setSpikeMonitor(DG_MOLAX, "DEFAULT");
                             
sim.setSpikeMonitor(DG_MOPP, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Neurogliaform, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Outer_Molecular_Layer, "DEFAULT");
                             
sim.setSpikeMonitor(DG_Total_Molecular_Layer, "DEFAULT");
                             
