sim.setSpikeMonitor(EC_LI_II_Multipolar_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LI_II_Pyramidal_Fan, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LII_III_Pyramidal_Multiform, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LII_Oblique_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LII_Stellate, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LII_III_Pyramidal_Tripolar, "DEFAULT");
                             
sim.setSpikeMonitor(LEC_LIII_Multipolar_Principal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Multipolar_Principal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIII_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(LEC_LIII_Complex_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Complex_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Bipolar_Complex_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIII_Pyramidal_Stellate, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIII_Stellate, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIII_V_Bipolar_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIV_V_Pyramidal_Horizontal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIV_VI_Deep_Multipolar_Principal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LV_Multipolar_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LV_Deep_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LV_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LV_Superficial_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LV_VI_Pyramidal_Polymorphic, "DEFAULT");
                             
sim.setSpikeMonitor(LEC_LVI_Multipolar_Pyramidal, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LII_Axo_Axonic, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LII_Basket, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LII_Basket_Multipolar_Interneuron, "DEFAULT");
                             
sim.setSpikeMonitor(LEC_LIII_Multipolar_Interneuron, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Multipolar_Interneuron, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Superficial_Multipolar_Interneuron, "DEFAULT");
                             
sim.setSpikeMonitor(EC_LIII_Pyramidal_Looking_Interneuron, "DEFAULT");
                             
sim.setSpikeMonitor(MEC_LIII_Superficial_Trilayered_Interneuron, "DEFAULT");
                             
